<?php
declare(strict_types=1);

require_once __DIR__ . '/../../includes/bootstrap.php';

require_role('Security Manager');


$applicationId = filter_input(
    INPUT_GET,
    'application_id',
    FILTER_VALIDATE_INT
);


if (
    $applicationId === false
    || $applicationId === null
    || $applicationId <= 0
) {

    set_flash(
        'error',
        'معرف الطلب غير صالح.'
    );

    redirect(
        'manager/analyst-applications/index.php'
    );
}


$statement = db()->prepare(
    "SELECT
        application_id,
        first_name,
        last_name,
        email,
        status
     FROM analyst_applications
     WHERE application_id = :application_id
     LIMIT 1"
);


$statement->execute([
    'application_id' => $applicationId,
]);


$application = $statement->fetch();


if ($application === false) {

    set_flash(
        'error',
        'لم يتم العثور على الطلب.'
    );

    redirect(
        'manager/analyst-applications/index.php'
    );
}


if ($application['status'] !== 'pending') {

    set_flash(
        'error',
        'هذا الطلب تمت مراجعته مسبقًا.'
    );

    redirect(
        'manager/analyst-applications/view.php?application_id='
        . $applicationId
    );
}


$errors = [];


if (is_post_request()) {

    require_valid_csrf();


    $reason = trim(
        (string) (
            $_POST['rejection_reason'] ?? ''
        )
    );


    if ($reason === '') {

        $errors[] =
            'يجب إدخال سبب رفض الطلب.';
    }


    if (strlen($reason) > 500) {

        $errors[] =
            'سبب الرفض يجب ألا يتجاوز 500 حرف.';
    }

    $currentUser = current_user();

    $currentUserId = $currentUser !== null
        ? (int) $currentUser['user_id']
        : 0;


    if ($currentUserId <= 0) {

        $errors[] =
            'تعذر تحديد المستخدم الحالي.';
    }


    if ($errors === []) {

        db()->beginTransaction();


        try {

            $updateStatement = db()->prepare(
                "UPDATE analyst_applications
                 SET
                    status = 'rejected',
                    reviewed_by = :reviewed_by,
                    reviewed_at = NOW(),
                    rejection_reason = :rejection_reason
                 WHERE application_id = :application_id
                   AND status = 'pending'"
            );


            $updateStatement->execute([
                'reviewed_by' => $currentUserId,
                'rejection_reason' => $reason,
                'application_id' => $applicationId,
            ]);


            if ($updateStatement->rowCount() !== 1) {

                throw new RuntimeException(
                    'The application could not be rejected.'
                );
            }


            record_audit(
                'REJECT_ANALYST_APPLICATION',
                'analyst_applications',
                $applicationId,
                [
                    'status' => 'pending',
                ],
                [
                    'status' => 'rejected',
                    'reviewed_by' => $currentUserId,
                    'rejection_reason' => $reason,
                ]
            );


            db()->commit();


            set_flash(
                'success',
                'تم رفض طلب المحلل الأمني.'
            );


            redirect(
                'manager/analyst-applications/view.php?application_id='
                . $applicationId
            );


        } catch (Throwable $exception) {

            db()->rollBack();

            $errors[] =
                'حدث خطأ أثناء رفض الطلب.';
        }
    }
}


render_header('رفض طلب محلل أمني');
?>

<section class="page-heading">

    <div>

        <p class="eyebrow">
            طلبات المحللين الأمنيين
        </p>

        <h1>
            رفض الطلب
        </h1>

        <p class="muted">
            أدخل سببًا واضحًا ومختصرًا لرفض الطلب.
        </p>

    </div>


    <div class="page-actions">

        <a href="<?= e(
            url(
                'manager/analyst-applications/view.php?application_id='
                . $applicationId
            )
        ) ?>" class="button button-primary">
            العودة إلى الطلب
        </a>

    </div>

</section>


<section class="details-card">

    <div class="detail-grid">

        <div>

            <span class="detail-label">
                المتقدم
            </span>

            <strong>
                <?= e(
                    trim(
                        (string) $application['first_name']
                        . ' '
                        . (string) $application['last_name']
                    )
                ) ?>
            </strong>

        </div>


        <div>

            <span class="detail-label">
                البريد الإلكتروني
            </span>

            <strong>
                <?= e(
                    (string) $application['email']
                ) ?>
            </strong>

        </div>

    </div>

</section>


<section class="details-card">

    <?php if ($errors !== []): ?>

        <div class="alert alert-error">

            <ul>

                <?php foreach ($errors as $error): ?>

                    <li>
                        <?= e($error) ?>
                    </li>

                <?php endforeach; ?>

            </ul>

        </div>

    <?php endif; ?>


    <form method="post">

        <?= csrf_input() ?>


        <div class="form-field">

            <label for="rejection_reason">
                سبب رفض الطلب
            </label>

            <textarea id="rejection_reason" name="rejection_reason" rows="7" maxlength="500" required
                placeholder="اكتب سبب رفض الطلب..."><?= e(
                    (string) (
                        $_POST['rejection_reason']
                        ?? ''
                    )
                ) ?></textarea>

            <small>
                الحد الأقصى 500 حرف.
            </small>

        </div>


        <div class="form-actions">

            <a href="<?= e(
                url(
                    'manager/analyst-applications/view.php?application_id='
                    . $applicationId
                )
            ) ?>" class="button button-secondary">
                إلغاء
            </a>


            <button type="submit" class="button button-danger">
                تأكيد رفض الطلب
            </button>

        </div>

    </form>

</section>

<?php render_footer(); ?>