<?php
declare(strict_types=1);

require_once __DIR__ . '/../../includes/bootstrap.php';

require_role('Security Manager');


/*
 * Only POST requests are allowed.
 */
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    set_flash(
        'error',
        'طريقة الطلب غير صحيحة.'
    );

    redirect(
        'manager/analyst-applications/index.php'
    );
}


/*
 * CSRF protection.
 */
require_valid_csrf();


/*
 * Get application ID.
 */
$applicationId = filter_input(
    INPUT_POST,
    'application_id',
    FILTER_VALIDATE_INT
);


if (
    $applicationId === false
    || $applicationId === null
    || $applicationId <= 0
) {

    set_flash(
        'error',
        'معرف الطلب غير صالح.'
    );

    redirect(
        'manager/analyst-applications/index.php'
    );
}


/*
 * Get current authenticated manager.
 *
 * IMPORTANT:
 * The project stores the authenticated user inside
 * $_SESSION['user'], and current_user() provides it.
 */
$currentUser = current_user();


if ($currentUser === null) {

    set_flash(
        'error',
        'تعذر تحديد المستخدم الحالي.'
    );

    redirect(
        'manager/analyst-applications/index.php'
    );
}


$currentUserId = (int) $currentUser['user_id'];


if ($currentUserId <= 0) {

    set_flash(
        'error',
        'معرف المستخدم الحالي غير صالح.'
    );

    redirect(
        'manager/analyst-applications/index.php'
    );
}


/*
 * Get the application.
 */
$statement = db()->prepare(
    "SELECT
        application_id,
        first_name,
        last_name,
        email,
        status
     FROM analyst_applications
     WHERE application_id = :application_id
     LIMIT 1"
);


$statement->execute([
    'application_id' => $applicationId,
]);


$application = $statement->fetch();


if ($application === false) {

    set_flash(
        'error',
        'لم يتم العثور على الطلب.'
    );

    redirect(
        'manager/analyst-applications/index.php'
    );
}


/*
 * Only pending applications can be approved.
 */
if (
    (string) $application['status']
    !== 'pending'
) {

    set_flash(
        'error',
        'هذا الطلب تمت مراجعته مسبقًا.'
    );

    redirect(
        'manager/analyst-applications/view.php?application_id='
        . $applicationId
    );
}


/*
 * Update application.
 */
db()->beginTransaction();


try {

    $updateStatement = db()->prepare(
        "UPDATE analyst_applications
         SET
            status = 'approved',
            reviewed_by = :reviewed_by,
            reviewed_at = NOW(),
            rejection_reason = NULL
         WHERE application_id = :application_id
           AND status = 'pending'"
    );


    $updateStatement->execute([
        'reviewed_by' => $currentUserId,
        'application_id' => $applicationId,
    ]);


    /*
     * Make sure exactly one pending application
     * was changed.
     */
    if ($updateStatement->rowCount() !== 1) {

        throw new RuntimeException(
            'The application status was not updated.'
        );
    }


    /*
     * Audit the approval.
     */
    record_audit(
        'APPROVE_ANALYST_APPLICATION',
        'analyst_applications',
        $applicationId,
        [
            'status' => 'pending',
        ],
        [
            'status' => 'approved',
            'reviewed_by' => $currentUserId,
        ]
    );


    /*
     * Commit both operations.
     */
    db()->commit();


    set_flash(
        'success',
        'تم قبول طلب المحلل الأمني بنجاح.'
    );


    redirect(
        'manager/analyst-applications/view.php?application_id='
        . $applicationId
    );


} catch (Throwable $exception) {

    /*
     * Roll back the database transaction.
     */
    if (db()->inTransaction()) {
        db()->rollBack();
    }


    /*
     * Log the real error on the server.
     *
     * We do not expose database details to the user.
     */
    error_log(
        'Approve analyst application error: '
        . $exception->getMessage()
    );


    set_flash(
        'error',
        'حدث خطأ أثناء قبول الطلب.'
    );


    redirect(
        'manager/analyst-applications/view.php?application_id='
        . $applicationId
    );
}